import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
 

public final class UI {
	
	
    /**
     * Default constructor--private to prevent instantiation.
     */
    private UI() {}
    
    private static String DATABASE = "Project_DB.db";

    
    /**
     * Queries the database and prints the results.
     * 
     * @param conn a connection object
     * @param sql a SQL statement that returns rows
     * This query is written with the Statement class, tipically 
     * used for static SQL SELECT statements
     */
    public static void sqlQuery(Connection conn, String sql){
        try {
        	Statement stmt = conn.createStatement();
        	ResultSet rs = stmt.executeQuery(sql);
        	ResultSetMetaData rsmd = rs.getMetaData();
        	int columnCount = rsmd.getColumnCount();
        	for (int i = 1; i <= columnCount; i++) {
        		String value = rsmd.getColumnName(i);
        		System.out.print(value);
        		if (i < columnCount) System.out.print(",  ");
        	}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    

    public static Connection initializeDB(String databaseFileName) {
        /**
         * The "Connection String" or "Connection URL".
         *
         * "jdbc:sqlite:" is the "subprotocol". (If this were a SQL Server
         * database it would be "jdbc:sqlserver:".)
         */
        String url = "jdbc:sqlite:" + databaseFileName;
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("There was a problem connecting to the database.");
        }
        return conn;
    }
    
    
    public static void printResultSet(ResultSet rs) {
    	try {
	    	ResultSetMetaData rsmd = rs.getMetaData();
	    	int columnCount = rsmd.getColumnCount();
	    	for (int i = 1; i <= columnCount; i++) {
	    		String value = rsmd.getColumnName(i);
	    		System.out.print(value);
	    		if (i < columnCount) System.out.print(",  ");
	    	}
			System.out.print("\n");
	    	while (rs.next()) {
	    		for (int i = 1; i <= columnCount; i++) {
	    			String columnValue = rs.getString(i);
	        		System.out.print(columnValue);
	        		if (i < columnCount) System.out.print(",  ");
	    		}
				System.out.print("\n");
	    	}
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }

 
    public static int insertMember(Connection conn, String user_Id, String fname, String lname, String addr, String phone, String email, String start_Date, String credit_Card) {
        String sql = "INSERT INTO MEMBER VALUES(?,?,?,?,?,?,?,?)";
        int success = 0;

        try {
        	PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, user_Id);
            psmt.setString(2, fname);
            psmt.setString(3, lname);
            psmt.setString(4, addr);
            psmt.setString(5, phone);
            psmt.setString(6, email);
            psmt.setString(7, start_Date);
            psmt.setString(8, credit_Card);
            success = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return success;
    }
    
    public static int insertDrone(Connection conn, String fleet_Id, String model_Num, String serial_Num, String year, String desc, String warr_Exp, int weight_Cap, int volume_Cap, String dist_Auth, int max_Speed, int status, String addr, String city, String supp_Id) {
        String sql = "INSERT INTO DRONE VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int success = 0;

        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, fleet_Id);
            psmt.setString(2, model_Num);
            psmt.setString(3, serial_Num);
            psmt.setString(4, year);
            psmt.setString(5, desc);
            psmt.setString(6, warr_Exp);
            psmt.setInt(7, weight_Cap);
            psmt.setInt(8, volume_Cap);
            psmt.setString(9, dist_Auth);
            psmt.setInt(10, max_Speed);
            psmt.setInt(11, status);
            psmt.setString(12, addr);
            psmt.setString(13, city);
            psmt.setString(14, supp_Id);
            success = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return success;
    }
    
    public static int insertEquipment(Connection conn, String inv_Id, String model_Num, String serial_Num, String year, String desc, String warr_Exp, String type, int weight, String arrival_Date, String size, String addr, String city, String supp_Id) {
        String sql = "INSERT INTO EQUIPMENT VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int success = 0;

        try {PreparedStatement psmt = conn.prepareStatement(sql); 

            psmt.setString(1, inv_Id);
            psmt.setString(2, model_Num);
            psmt.setString(3, serial_Num);
            psmt.setString(4, year);
            psmt.setString(5, desc);
            psmt.setString(6, warr_Exp);
            psmt.setString(7, type);
            psmt.setInt(8, weight);
            psmt.setString(9, arrival_Date);
            psmt.setString(10, size);
            psmt.setString(11, addr);
            psmt.setString(12, city);
            psmt.setString(13, supp_Id);
            success = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return success;
    }

    public static int insertCustOrder(Connection conn, String order_Num, int value, String order_Date, String return_Date, int return_Status, String inv_Id, String fleet_Id, String user_Id) {
    	String sql = "INSERT INTO CUST_ORDER VALUES (?,?,?,?,?,?,?,?)";
    	int success = 0;
    	
    	try {
    		PreparedStatement psmt = conn.prepareStatement(sql);
    		psmt.setString(1, order_Num);
    		psmt.setInt(2, value);
    		psmt.setString(3, order_Date);
    		psmt.setString(4, return_Date);
    		psmt.setInt(5, return_Status);
    		psmt.setString(6, inv_Id);
    		psmt.setString(7, fleet_Id);
    		psmt.setString(8, user_Id);
    		success = psmt.executeUpdate();
    	}
    	catch(SQLException e){
    		System.out.println(e.getMessage());
    	}
    	return success;
    }

    public static int insertEmployee(Connection conn, String ssn, String fName, String lName, String addr, String phone, String email, int salary) {
    	String sql = "INSERT INTO EMPLOYEE VALUES (?,?,?,?,?,?, ?)";
    	int success = 0;
    	try {
    		PreparedStatement psmt = conn.prepareStatement(sql);
    		psmt.setString(1, ssn);
    		psmt.setString(2, fName);
    		psmt.setString(3, lName);
    		psmt.setString(4, addr);
    		psmt.setString(5, phone);
    		psmt.setString(6, email);
    		psmt.setInt(7, salary);
    		success = psmt.executeUpdate();
    	}
    	
    catch(SQLException e){
    		System.out.println(e.getMessage());
    	}
    	return success;
    }
    
    public static int insertDrone_Order(Connection conn, String order_Num, int value, String order_Date, String est_DOA, int num_Items, String type, String ssn, String fleet_Id)
    {
	    String sql = "INSERT INTO INV_ORDER VALUES (?,?,?,?,?,?,?)";
	    String sql1 = "INSERT INTO FOR_DRONE VALUES (?,?)";
	    int success = 0;
	    try {
	    	PreparedStatement psmt = conn.prepareStatement(sql);
	    	psmt.setString(1, order_Num);
	    	psmt.setInt(2, value);
	    	psmt.setString(3, order_Date);
	    	psmt.setString(4, est_DOA);
	    	psmt.setInt(5, num_Items);
	    	psmt.setString(6, type);
	    	psmt.setString(7, ssn);
	    	success += psmt.executeUpdate();
	    	}
	    catch(SQLException e){
	    		System.out.println(e.getMessage());
	    	}
	    
	    try {
	    	PreparedStatement psmt1 = conn.prepareStatement(sql1);
	    	psmt1.setString(1, order_Num);
	    	psmt1.setString(2, fleet_Id);
	    	success += psmt1.executeUpdate();
	    	}
	    catch(SQLException e){
	    		System.out.println(e.getMessage());
	    	}
	    	return success;
    }
    
    public static int insertEquip_Order(Connection conn, String order_Num, int value, String order_Date, String est_DOA, int num_Items, String type, String ssn, String inv_Id)
    {
	     String sql = "INSERT INTO INV_ORDER VALUES (?,?,?,?,?,?,?)";
	    String sql1 = "INSERT INTO FOR_EQUIP VALUES (?,?)";
	    int success = 0;
	    try {
	    	PreparedStatement psmt = conn.prepareStatement(sql);
	    	psmt.setString(1, order_Num);
	    	psmt.setInt(2, value);
	    	psmt.setString(3, order_Date);
	    	psmt.setString(4, est_DOA);
	    	psmt.setInt(5, num_Items);
	    	psmt.setString(6, type);
	    	psmt.setString(7, ssn);
	    	success += psmt.executeUpdate();
	    	}
	    catch(SQLException e){
	    		System.out.println(e.getMessage());
	    	}
	    
	    try {
	    	PreparedStatement psmt1 = conn.prepareStatement(sql1);
	    	psmt1.setString(1, order_Num);
	    	psmt1.setString(2, inv_Id);
	    	success += psmt1.executeUpdate();
	    	}
	    catch(SQLException e){
	    		System.out.println(e.getMessage());
	    	}
	    	return success;
    }
    
    public static int insertReview(Connection conn, String review_Id, String rating, String text, String user_Id, String inv_Id){
    	String sql = "INSERT INTO REVIEW VALUES (?,?,?,?,?)";
    	int success = 0;
    	try {
    		PreparedStatement psmt = conn.prepareStatement(sql);
    		psmt.setString(1, review_Id);
    		psmt.setString(2, rating);
    		psmt.setString(3, text);
    		psmt.setString(4, user_Id);
    		psmt.setString(5, inv_Id);
    		success += psmt.executeUpdate();
    		return success;
    	}
    	catch(SQLException e) {
    		System.out.println(e.getMessage());
     }
    	return success;
    }
    
    public static int insertSupplier(Connection conn, String supp_Id, String name, String addr, String city) {
    	String sql = "INSERT INTO SUPPLIER VALUES (?,?,?,?)";
    	int success = 0;

    	try {
    		PreparedStatement psmt = conn.prepareStatement(sql);
    		psmt.setString(1, supp_Id);
    		psmt.setString(2, name);
    		psmt.setString(3, addr);
    		psmt.setString(4, city);
    		success += psmt.executeUpdate();
    	}
    	catch(SQLException e) {
    		System.out.println(e.getMessage());
    }
    	return success;
    }
    
    public static int insertWarehouse(Connection conn, String addr, String city, String mgrFname, String mgrLname, String phone, int equip_cap, int drone_cap) {

    	String sql = "INSERT INTO WAREHOUSE VALUES (?,?,?,?,?,?,?)";
    	int success = 0;

    	try{
    		PreparedStatement psmt = conn.prepareStatement(sql);
    		psmt.setString(1, addr);
    		psmt.setString(2, city);
    		psmt.setString(3, mgrFname);
    		psmt.setString(4, mgrLname);
    		psmt.setString(5, phone);
    		psmt.setInt(6, equip_cap);
    		psmt.setInt(7, drone_cap);
    		success += psmt.executeUpdate();
    		}
    	catch(SQLException e) {
    		System.out.println(e.getMessage());
    	}
    	return success;
    }

    
    public static int deleteFromCUST_ORDER(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM CUST_ORDER WHERE Order_Num = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromDRONE(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM DRONE WHERE Fleet_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromEMPLOYEE(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM EMPLOYEE WHERE Ssn = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromEQUIPMENT(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM EQUIPMENT WHERE Inv_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromFOR_DRONE(Connection conn, String Order_Num,
            String Fleet_Id) {

        int result = 0;
        String sql = "DELETE FROM FOR_DRONE WHERE Order_Num = ? AND Fleet_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, Order_Num);
            psmt.setString(2, Fleet_Id);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromFOR_EQUIP(Connection conn, String Order_Num,
            String Inv_Id) {

        int result = 0;
        String sql = "DELETE FROM FOR_EQUIP WHERE Order_Num = ? AND Fleet_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, Order_Num);
            psmt.setString(2, Inv_Id);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromINV_ORDER(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM INV_ORDER WHERE Order_Num = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromMEMBER(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM MEMBER WHERE User_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromREVIEW(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM REVIEW WHERE Review_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromSUPPLIER(Connection conn, String key) {

        int result = 0;
        String sql = "DELETE FROM SUPPLIER WHERE Supp_Id = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, key);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static int deleteFromWAREHOUSE(Connection conn, String addr,
            String city) {

        int result = 0;
        String sql = "DELETE FROM WAREHOUSE WHERE Addr = ? AND City = ?";
        try {
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, addr);
            psmt.setString(2, city);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }
    

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Connection conn = initializeDB(DATABASE);

        System.out.println("What would you like to do: ");
        System.out.println("[ENTER DATA]");
        System.out.println("[EDIT]");
        System.out.println("[DELETE ENTRY]");
        System.out.println("[SEARCH]");
        System.out.println("[USEFUL REPORTS]");
        String input = in.nextLine();

        String table = "";
        if (!input.equals("USEFUL REPORTS")) {
            System.out.println("What table do you want to " + input + ":");
            System.out.println("CUST_ORDER|DRONE|EMPLOYEE|EQUIPMENT|FOR_DRONE");
            System.out.println("FOR_EQUIP|INV_ORDER|MEMBER|REVIEW|SUPPLIER|");
            System.out.println("WAREHOUSE");
            table = in.nextLine();
        }

        switch (input) {
            case ("ENTER DATA"):
            	System.out.println("Enter Each Element of Data in Order on a new Line:");
            	Scanner eIn = new Scanner(System.in);
                switch (table ) { 
                    case ("CUST_ORDER"):
                    	String orderNum = eIn.nextLine();
                    	int value = eIn.nextInt();
                    	String orderDate = eIn.nextLine();
                    	String returnDate = eIn.nextLine();
                    	int returnStatus = eIn.nextInt();
                    	String inv_Id = eIn.nextLine();
                    	String fleet_Id = eIn.nextLine();
                    	String user_Id = eIn.nextLine();
                    	int coSuccess = insertCustOrder(conn, orderNum, value, orderDate, returnDate, returnStatus, inv_Id, fleet_Id, user_Id);
                    	if(coSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("DRONE"):
                    	String fleetId = eIn.nextLine();
                    	String modelNum = eIn.nextLine();
                    	String serialNum = eIn.nextLine();
                    	String year = eIn.nextLine();
                    	String desc = eIn.nextLine();
                    	String warrExp = eIn.nextLine();
                    	int weightCap = eIn.nextInt();
                    	int volCap = eIn.nextInt();
                    	String distAuth = eIn.nextLine();
                    	int maxSpd = eIn.nextInt();
                    	int status = eIn.nextInt();
                    	String dAddr = eIn.nextLine();
                    	String city = eIn.nextLine();
                    	String suppId = eIn.nextLine();
                    	int dSuccess = insertDrone(conn, fleetId, modelNum, serialNum, year, desc, warrExp,
                    			weightCap, volCap, distAuth, maxSpd, status, dAddr, city, suppId);
                    	if(dSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("EMPLOYEE"):
                    	String ssn = eIn.nextLine();
                    	String fName = eIn.nextLine();
                    	String lName = eIn.nextLine();
                    	String eAddr = eIn.nextLine();
                    	String ePhone = eIn.nextLine();
                    	String eEmail = eIn.nextLine();
                    	int salary = eIn.nextInt();
                    	int eSuccess = insertEmployee(conn, ssn, fName, lName, eAddr, ePhone, eEmail, salary);
                    	if(eSuccess == 1) {
                    		System.out.println("Successful Insertion. \n");
                    	}
                        break;
                    case ("EQUIPMENT"):
                    	String eqInvId = eIn.nextLine();
                    	String eqModelNum = eIn.nextLine();
                    	String eqSerialNum = eIn.nextLine();
                    	String eqYear = eIn.nextLine();
                    	String eqDesc = eIn.nextLine();
                    	String eqWarrExp = eIn.nextLine();
                    	String eqType = eIn.nextLine();
                    	int eqWeight = eIn.nextInt();
                    	String eqArrDate = eIn.nextLine();
                    	String eqSize = eIn.nextLine();
                    	String eqAddr = eIn.nextLine();
                    	String eqCity = eIn.nextLine();
                    	String eqSuppId = eIn.nextLine();
                    	int eqSuccess = insertEquipment(conn, eqInvId, eqModelNum, eqSerialNum, eqYear, eqDesc, eqWarrExp, eqType,
                    			eqWeight, eqArrDate, eqSize, eqAddr, eqCity, eqSuppId);
                    	if(eqSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("EQUIP_ORDER"): //HANDLES INV_ORDER AND FOR_EQUIP
                    	System.out.println("Include inv_Id at the End:");
                    	String eoOrderNum = eIn.nextLine();
                    	int eoValue = eIn.nextInt();
                    	String eoOrderDate = eIn.nextLine();
                    	String eoEstDoa = eIn.nextLine();
                    	int eoNumItems = eIn.nextInt();
                    	String eoType = eIn.nextLine();
                    	String eoSsn = eIn.nextLine();
                    	String eoInvId = eIn.nextLine();
                    	int eoSuccess = insertEquip_Order(conn, eoOrderNum, eoValue, eoOrderDate, eoEstDoa,
                    			eoNumItems, eoType, eoSsn, eoInvId);
                    	if(eoSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                    	
                    	break;
                    case ("DRONE_ORDER"): //HANDLES INV_ODER AND FOR_DRONE
                    	System.out.println("Include fleet_Id at the End:");
                    	String doOrderNum = eIn.nextLine();
                    	int doValue = eIn.nextInt();
                    	String doOrderDate = eIn.nextLine();
                    	String doEstDoa = eIn.nextLine();
                    	int doNumItems = eIn.nextInt();
                    	String doType = eIn.nextLine();
                    	String doSsn = eIn.nextLine();
                    	String doFleetId = eIn.nextLine();
                    	int doSuccess = insertDrone_Order(conn, doOrderNum, doValue, doOrderDate, doEstDoa,
                    			doNumItems, doType, doSsn, doFleetId);
                    	if(doSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("MEMBER"):
                    	String mUserId = eIn.nextLine();
                    	String mFname = eIn.nextLine();
                    	String mLname = eIn.nextLine();
                    	String mAddr = eIn.nextLine();
                    	String mPhone = eIn.nextLine();
                    	String mEmail = eIn.nextLine();
                    	String mStartDate = eIn.nextLine();
                    	String mCreditCard = eIn.nextLine();
                    	int mSuccess = insertMember(conn, mUserId, mFname, mLname, mAddr, mPhone,
                    			mEmail, mStartDate, mCreditCard);
                    	if(mSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("REVIEW"):
                    	String reviewId = eIn.nextLine();
                    	String rating = eIn.nextLine();
                    	String text = eIn.nextLine();
                    	String rUserId = eIn.nextLine();
                    	String rInvId = eIn.nextLine();
                    	int rSuccess = insertReview(conn, reviewId, rating, text, rUserId, rInvId);
                    	if(rSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("SUPPLIER"):
                    	String sSuppId = eIn.nextLine();
                    	String sName = eIn.nextLine();
                    	String sAddr = eIn.nextLine();
                    	String sCity = eIn.nextLine();
                    	int sSuccess = insertSupplier(conn, sSuppId, sName, sAddr, sCity);
                    	if(sSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                        break;
                    case ("WAREHOUSE"):
                    	String wAddr = eIn.nextLine();
                    	String wCity = eIn.nextLine();
                    	String wMgrFname = eIn.nextLine();
                    	String wMgrLname = eIn.nextLine();
                    	String wPhone = eIn.nextLine();
                    	int wEquipCap = eIn.nextInt();
                    	int wDroneCap = eIn.nextInt();
                    	int wSuccess = insertWarehouse(conn, wAddr, wCity, wMgrFname, wMgrLname,
                    			wPhone, wEquipCap, wDroneCap);
                    	if(wSuccess == 1) {
                    		System.out.println("Successful Insertion.\n");
                    	}
                    	
                    	
                        break;
                    default:
                        System.out.println("ERROR: Incorrect input.");
                }
            case ("EDIT"):
                break;
            case("DELETE ENTRY"):
            	switch (table) {
	                case ("CUST_ORDER"):
	                    System.out.print("Enter Order_Num: ");
	                    String Order_Num = in.nextLine();
	                    int result0 = deleteFromCUST_ORDER(conn, Order_Num);
	                    if (result0 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("DRONE"):
	                    System.out.print("Enter Fleet_Id: ");
	                    String Fleet_Id = in.nextLine();
	                    int result1 = deleteFromDRONE(conn, Fleet_Id);
	                    if (result1 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("EMPLOYEE"):
	                    System.out.print("Enter Ssn: ");
	                    String ssn = in.nextLine();
	                    int result2 = deleteFromEMPLOYEE(conn, ssn);
	                    if (result2 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("EQUIPMENT"):
	                    System.out.print("Enter Inv_Id: ");
	                    String Inv_Id = in.nextLine();
	                    int result3 = deleteFromEQUIPMENT(conn, Inv_Id);
	                    if (result3 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("FOR_DRONE"):
	                    System.out.print("Enter Order_Num: ");
	                    String Order_NumD = in.nextLine();
	                    System.out.print("Enter Fleet_Id: ");
	                    String Fleet_IdD = in.nextLine();
	                    int result4 = deleteFromFOR_DRONE(conn, Order_NumD,
	                            Fleet_IdD);
	                    if (result4 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("FOR_EQUIP"):
	                    System.out.print("Enter Order_Num: ");
	                    String Order_NumE = in.nextLine();
	                    System.out.print("Enter Fleet_Id: ");
	                    String Fleet_IdE = in.nextLine();
	                    int result5 = deleteFromFOR_EQUIP(conn, Order_NumE,
	                            Fleet_IdE);
	                    if (result5 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("INV_ORDER"):
	                    System.out.print("Enter Order_Num: ");
	                    String Order_NumI = in.nextLine();
	                    int result6 = deleteFromINV_ORDER(conn, Order_NumI);
	                    if (result6 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("MEMBER"):
	                    System.out.print("Enter User_Id: ");
	                    String User_Id = in.nextLine();
	                    int result7 = deleteFromMEMBER(conn, User_Id);
	                    if (result7 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("REVIEW"):
	                    System.out.print("Enter Review_Id: ");
	                    String Review_Id = in.nextLine();
	                    int result8 = deleteFromREVIEW(conn, Review_Id);
	                    if (result8 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("SUPPLIER"):
	                    System.out.print("Enter Supp_Id: ");
	                    String Supp_Id = in.nextLine();
	                    int result9 = deleteFromSUPPLIER(conn, Supp_Id);
	                    if (result9 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                case ("WAREHOUSE"):
	                    System.out.print("Enter Address: ");
	                    String addr = in.nextLine();
	                    System.out.print("Enter City: ");
	                    String city = in.nextLine();
	                    int result10 = deleteFromWAREHOUSE(conn, addr, city);
	                    if (result10 == 1) {
	                        System.out.println("Sucess");
	                    } else {
	                        System.out.println("Failure");
	                    }
	                    break;
	                default:
	                    System.out.println("ERROR: Incorrect input.");
	            }
	            break;
            case("SEARCH"):
	        	switch (table) {
	                case("CUST_ORDER"):
	                	System.out.println("Enter Order_Num:");
		        		String pk0 = in.nextLine();
	                	String query0 = "SELECT * FROM CUST_ORDER WHERE Order_Num = ?";
						try {
							PreparedStatement stmt = conn.prepareStatement(query0);
							stmt.setString(1, pk0);
							ResultSet rs = stmt.executeQuery();
							printResultSet(rs);
						} catch (SQLException e) {
							e.printStackTrace();
						}
	                	break;
	                case("DRONE"):
	                	System.out.println("Enter Fleet_Id:");
	        			String pk1 = in.nextLine();
	                	String query1 = "SELECT * FROM DRONE WHERE Fleet_id = ?";
	                	try {
							PreparedStatement stmt = conn.prepareStatement(query1);
							stmt.setString(1, pk1);
							ResultSet rs = stmt.executeQuery();
							printResultSet(rs);
						} catch (SQLException e) {
							e.printStackTrace();
						}
	                	break;
	                case ("EMPLOYEE"):
	                	System.out.println("Enter Ssn:");
	        			String pk2 = in.nextLine();
	                    String query2 = "SELECT * FROM EMPLOYEE WHERE Ssn = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query2);
	                        stmt.setString(1, pk2);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("EQUIPMENT"):
	                	System.out.println("Enter Inv_Id:");
	        			String pk3 = in.nextLine();
	                    String query3 = "SELECT * FROM EQUIPMENT WHERE Inv_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query3);
	                        stmt.setString(1, pk3);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("FOR_DRONE"):
	                	System.out.println("Enter Order_Num:");
	        			String pk4 = in.nextLine();
	        			System.out.println("Enter Fleet_Id:");
	        			String pk4b = in.nextLine();
	                    String query4 = "SELECT * FROM FOR_DRONE WHERE Order_Num = ? AND Fleet_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query4);
	                        stmt.setString(1, pk4);
	                        stmt.setString(2, pk4b);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("FOR_EQUIP"):
	                	System.out.println("Enter Order_Num:");
	        			String pk5 = in.nextLine();
	        			System.out.println("Enter Inv_Id:");
	        			String pk5b = in.nextLine();
	                    String query5 = "SELECT * FROM FOR_DRONE WHERE Order_Num = ? AND Inv_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query5);
	                        stmt.setString(1, pk5);
	                        stmt.setString(2, pk5b);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("INV_ORDER"):
	                	System.out.println("Enter Order_Num:");
	        			String pk6 = in.nextLine();
	                    String query6 = "SELECT * FROM EQUIPMENT WHERE Order_Num = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query6);
	                        stmt.setString(1, pk6);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("MEMBER"):
	                	System.out.println("Enter User_Id:");
	        			String pk7 = in.nextLine();
	                    String query7 = "SELECT * FROM EQUIPMENT WHERE User_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query7);
	                        stmt.setString(1, pk7);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("REVIEW"):
	                	System.out.println("Enter Review_Id:");
	        			String pk8 = in.nextLine();
	                    String query8 = "SELECT * FROM EQUIPMENT WHERE Review_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query8);
	                        stmt.setString(1, pk8);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("SUPPLIER"):
	                	System.out.println("Enter Supp_Id:");
	        			String pk9 = in.nextLine();
	                    String query9 = "SELECT * FROM EQUIPMENT WHERE Supp_Id = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query9);
	                        stmt.setString(1, pk9);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                case ("WAREHOUSE"):
	                	System.out.println("Enter Addr:");
	        			String pk10 = in.nextLine();
	        			System.out.println("Enter City:");
	        			String pk10b = in.nextLine();
	                    String query10 = "SELECT * FROM WAREHOUSE WHERE Addr = ? AND City = ?";
	                    try {
	                        PreparedStatement stmt = conn.prepareStatement(query10);
	                        stmt.setString(1, pk10);
	                        stmt.setString(2, pk10b);
	                        ResultSet rs = stmt.executeQuery();
	                        printResultSet(rs);
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    break;
	                default:
	                    System.out.println("ERROR: Incorrect input.");
	        	}
	        	break;
            case("USEFUL REPORTS"):
            	String report;
	            System.out.println("Enter the report you want to see:");
	            System.out.println("REPORTS:");
	            System.out.println("[1]: All equipment rented by a member");
	            System.out.println("[2]: Most popular item");
	            System.out.println("[3]: Most popular Manufacturer");
	            System.out.println("[4]: Most popular Drone");
	            System.out.println("[5]: Top user");
	            System.out.println("[6]: Find equipment by type before year");
	            report = in.nextLine();
	            switch (report) {
	                case ("1"):
	                	try {
		                	System.out.println("Enter User_Id");
		                	String uid = in.nextLine();
		                	PreparedStatement sqlStatement0 = conn.prepareStatement("SELECT User_Id AS User, COUNT(*) AS NumOrders FROM CUST_ORDER WHERE User_Id = ? GROUP BY User_Id;");
		                	sqlStatement0.setString(1, uid);
		                	ResultSet rs = sqlStatement0.executeQuery();
		                	printResultSet(rs);
	                	}
	                	catch (SQLException e) {
	                		System.out.println(e.getMessage());
	                	}
	                    break;
	                case ("2"):
	                    break;
	                case ("3"):
	                    break;
	                case ("4"):
	                    break;
	                case ("5"):
	                    break;
	                case ("6"):
	                    break;
	                default:
	                	System.out.println("Invalid input");
	            }
	            break;
            default:
            	System.out.println("ERROR: Incorrect input.");
        }
        
        in.close();
    }
}